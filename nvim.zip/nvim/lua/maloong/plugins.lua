local status, packer = pcall(require, "packer")
if (not status) then
  print("Packer is not installed")
  return
end


vim.cmd [[packadd packer.nvim]]

packer.startup(function(use)
  use 'wbthomason/packer.nvim'
  use 'eandrju/cellular-automaton.nvim'
  --  use 'mhinz/vim-startify'
  use {
    'svrana/neosolarized.nvim',
    requires = { 'tjdevries/colorbuddy.nvim' }
  }
  use 'nvim-lualine/lualine.nvim' -- Statusline
  use 'nvim-lua/plenary.nvim'     -- Common utilities
  use 'onsails/lspkind-nvim'      -- vscode-like pictograms
  use 'hrsh7th/cmp-buffer'        -- nvim-cmp source for buffer words
  use 'hrsh7th/cmp-nvim-lsp'      -- nvim-cmp source for neovim's built-in LSP
  use 'hrsh7th/nvim-cmp'          -- Completion

  use 'tyru/open-browser.vim'
  use 'aklt/plantuml-syntax'
  use 'weirongxu/plantuml-previewer.vim'
  use 'neovim/nvim-lspconfig'           -- LSP
  use 'jose-elias-alvarez/null-ls.nvim' -- Use Neovim as a language server to inject LSP diagnostics, code actions, and more via Lua

  use "potamides/pantran.nvim"
  use 'williamboman/mason.nvim'
  use 'williamboman/mason-lspconfig.nvim'

  use "lukas-reineke/indent-blankline.nvim" -- Show vertical lines
  use({
    "kylechui/nvim-surround",
    tag = "*", -- Use for stability; omit to use `main` branch for the latest features
    config = function()
      require("nvim-surround").setup({
        -- Configuration here, or leave empty to use defaults
      })
    end
  })

  use "f-person/git-blame.nvim"

  use 'nvimdev/lspsaga.nvim' -- LSP UIs
  use 'L3MON4D3/LuaSnip'
  use {
    'nvim-treesitter/nvim-treesitter',
    run = function() require('nvim-treesitter.install').update({ with_sync = true }) end,
  }
  use 'kyazdani42/nvim-web-devicons' -- File icons
  use 'nvim-telescope/telescope.nvim'
  use 'nvim-telescope/telescope-file-browser.nvim'
  use 'nvim-telescope/telescope-media-files.nvim'
  use 'windwp/nvim-autopairs'
  use 'windwp/nvim-ts-autotag'
  use { 'numToStr/Comment.nvim',
    requires = {
      'JoosepAlviste/nvim-ts-context-commentstring'
    }
  }
  use 'norcalli/nvim-colorizer.lua'
  use({
    "iamcco/markdown-preview.nvim",
    run = function() vim.fn["mkdp#util#install"]() end,
  })
  use 'akinsho/nvim-bufferline.lua'
  -- use 'github/copilot.vim'

  use 'lewis6991/gitsigns.nvim'
  use 'dinhhuy258/git.nvim' -- For git blame & browse
  use 'akinsho/toggleterm.nvim'
  use 'theprimeagen/harpoon'
  use 'mbbill/undotree'
  use 'mfussenegger/nvim-jdtls'
  -- use 'kyazdani42/nvim-tree.lua' -- Lua
  use {
    "folke/todo-comments.nvim",
    requires = { "nvim-lua/plenary.nvim" }
  }

  use {
    "rest-nvim/rest.nvim",
    requires = { "nvim-lua/plenary.nvim" }
  }
  -- helper for UI
  use 'MunifTanjim/nui.nvim'

  use {
    "askfiy/nvim-picgo",
    config = function()
      -- it doesn't require you to do any configuration
      require("nvim-picgo").setup({
        -- method to informe
        -- 1. notify
        -- 2. echo
        notice = "notify",
        -- Whether the generated markdown link saves the upload name of the image
        -- boolean
        image_name = false,
        -- debug mode
        debug = false,
      })
    end
  }

  use({
    'jameshiew/nvim-magic',
    config = function()
      require('nvim-magic').setup()
    end,
    requires = {
      'nvim-lua/plenary.nvim',
      'MunifTanjim/nui.nvim'
    }
  })

  use {
    'phaazon/hop.nvim',
    branch = 'v2', -- optional but strongly recommended
  }

  -- Packer
  use { 'sindrets/diffview.nvim', requires = 'nvim-lua/plenary.nvim' }

  use 'LudoPinelli/comment-box.nvim'
  -- command suggestion
  use 'gelguy/wilder.nvim'

  use 'stevearc/dressing.nvim'

  -- search and replace
  use({
    "ray-x/sad.nvim",
    requires = { "ray-x/guihua.lua", run = "cd lua/fzy && make" },
  })

  use 'anuvyklack/pretty-fold.nvim'
  use({
    'anuvyklack/fold-preview.nvim',
    requires = 'anuvyklack/keymap-amend.nvim',
    config = function()
      local fp = require('fold-preview')
      local map = require('fold-preview').mapping
      local keymap = vim.keymap
      keymap.amend = require('keymap-amend')

      fp.setup({
        default_keybindings = false
        -- another settings
      })

      keymap.amend('n', 'K', function(original)
        if not fp.show_preview() then original() end
        -- or
        -- if not fp.toggle_preview() then original() end
        -- to close preview on second press on K.
      end)
      keymap.amend('n', 'h', map.close_preview_open_fold)
      keymap.amend('n', 'l', map.close_preview_open_fold)
      keymap.amend('n', 'zo', map.close_preview)
      keymap.amend('n', 'zO', map.close_preview)
      keymap.amend('n', 'zc', map.close_preview_without_defer)
      keymap.amend('n', 'zR', map.close_preview)
      keymap.amend('n', 'zM', map.close_preview_without_defer)
    end
  })

  use 'itchyny/screensaver.vim'

  use({
    "folke/noice.nvim",
    requires = {
      -- if you lazy-load any plugin below, make sure to add proper `module="..."` entries
      "MunifTanjim/nui.nvim",
      -- OPTIONAL:
      --   `nvim-notify` is only needed, if you want to use the notification view.
      --   If not available, we use `mini` as the fallback
      "rcarriga/nvim-notify",
    }
  })

  -- Lua
  use {
    "folke/which-key.nvim",
    config = function()
      vim.o.timeout = true
      vim.o.timeoutlen = 300
      require("which-key").setup {
        -- your configuration comes here
        -- or leave it empty to use the default settings
        -- refer to the configuration section below
        window = {
          border = "double",        -- none, single, double, shadow
          position = "bottom",      -- bottom, top
          margin = { 1, 0, 1, 0 },  -- extra window margin [top, right, bottom, left]
          padding = { 2, 2, 2, 2 }, -- extra window padding [top, right, bottom, left]
          winblend = 0
        },
      }
    end
  }

  use({
    'mrjones2014/legendary.nvim',
    -- sqlite is only needed if you want to use frecency sorting
    requires = 'kkharji/sqlite.lua'
  })

  -- dashboard
  use {
    'glepnir/dashboard-nvim',
    event = 'VimEnter',
    config = function()
      require('dashboard').setup {
        theme = 'hyper',
        config = {
          week_header = {
            enable = true,
            concat = "",
            append = {
              "",
              "Don't let perfection become procrastination. Just Do It Now!",
              "If you know everyone is different, you will know yourself better!",
              "You never know how strong you are, until being strong is your only choice."
            }
          },
          footer = {
            "",
            "",
            "🐎🐲🐎🐲🐎🐲🐎🐲🎉"
          },
          packages = { enable = false },
          shortcut = {
            {
              desc = '📁Files',
              group = 'Label',
              --action = 'Telescope find_files',
              action = 'RnvimrToggle',
              key = 'f',
            },
            {
              desc = '🏠Apps',
              group = 'DiagnosticHint',
              action = 'ToggleTerm direction=float',
              key = 'a',
            },
            {
              desc = '⌚️Gits',
              group = '@property',
              action = 'lua _LAZYGIT_TOGGLE()',
              key = 'g'
            },
            {
              desc = '✍️ Plans',
              group = 'Number',
              action = 'lua _PLAN_TOGGLE()',
              key = 'p',
            },
          },
        },
      }
    end,
    requires = { 'nvim-tree/nvim-web-devicons' }
  }

  -- Packer
  -- use({
  --   "folke/drop.nvim",
  --   event = "VimEnter",
  --   config = function()
  --     require("drop").setup({
  --       ---@type DropTheme|string
  --       theme = "xmas",              -- leaves,snow,xmas,star, can be one of rhe default themes, or a custom theme
  --       max = 40,                    -- maximum number of drops on the screen
  --       interval = 150,              -- every 150ms we update the drops
  --       screensaver = 1000 * 60 * 5, -- show after 5 minutes. Set to false, to disable
  --       filetypes = {},              -- { "dashboard", "alpha", "starter" }, -- will enable/disable automatically for the following filetypes
  --       winblend = 0,
  --     })
  --   end,
  -- })

  use 'xiyaowong/nvim-transparent'

  use 'kevinhwang91/rnvimr'
end)
