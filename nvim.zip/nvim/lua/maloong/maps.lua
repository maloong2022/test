local keymap = vim.keymap


keymap.set('n', 'x', '"_x')

-- Increment/decrement
keymap.set('n', '+', '<C-a>')
keymap.set('n', '-', '<C-x>')

-- Delete a word backwards
keymap.set('n', 'dw', 'vb"_d')

-- Select all
keymap.set('n', '<C-a>', 'gg<S-v>G')

-- Save with root permission (not working for now)
--vim.api.nvim_create_user_command('W', 'w !sudo tee > /dev/null %', {})

-- New tab
keymap.set('n', 'te', ':tabedit')

-- Split window
keymap.set('n', 'ss', ':split<Return><C-w>w')
keymap.set('n', 'sv', ':vsplit<Return><C-w>w')
-- Move window
keymap.set('n', '<Space>', '<C-w>w')
keymap.set('', 'sh', '<C-w>h')
keymap.set('', 'sk', '<C-w>k')
keymap.set('', 'sj', '<C-w>j')
keymap.set('', 'sl', '<C-w>l')

-- Resize window
keymap.set('n', '<C-w><left>', '<C-w><')
keymap.set('n', '<C-w><right>', '<C-w>>')
keymap.set('n', '<C-w><up>', '<C-w>+')
keymap.set('n', '<C-w><down>', '<C-w>-')

-- Save document
keymap.set('n', '<C-s>', ':w<Return>')

-- ScreenSave
keymap.set('n', '<Leader>s', ':ScreenSaver<Return>')

-- diffview
keymap.set('n', '<Leader>d', ':DiffviewOpen<Return>')


-- toggleTerm
keymap.set('n', 'tw', ':ToggleTerm direction=float<Return>')

-- togglePrettier
-- keymap.set('','tp', ':Prettier<Return>')

-- NvimTree
--keymap.set('n', 'tt', ':NvimTreeToggle<Return>')

-- Markdown preview
keymap.set('n', 'md', ':MarkdownPreview<Return>')
keymap.set('n', 'mc', ':MarkdownPreviewStop<Return>')

-- Sad
keymap.set('n', '<C-r>', ':Sad<Return>')

-- Rnvimr
keymap.set('n', 'ff', ':RnvimrToggle<CR>')

-- legendary
keymap.set('', '<Leader>z', ':Legendary<Return>')

-- comment key binding
-- left aligned fixed size box with left aligned text
keymap.set("n", "<Leader>bb", "<Cmd>lua require('comment-box').lbox()<CR>")
keymap.set("v", "<Leader>bb", "<Cmd>lua require('comment-box').lbox()<CR>")

-- centered adapted box with centered text
keymap.set("n", "<Leader>bc", "<Cmd>lua require('comment-box').accbox()<CR>")
keymap.set("v", "<Leader>bc", "<Cmd>lua require('comment-box').accbox()<CR>")

-- centered line
keymap.set("n", "<Leader>bl", "<Cmd>lua require('comment-box').cline()<CR>")
keymap.set("i", "<M-l>", "<Cmd>lua require('comment-box').cline()<CR>")

-- make it rain
keymap.set("n", "<leader>mr", "<Cmd>CellularAutomaton make_it_rain<CR>")
keymap.set("n", "<leader>mf", "<Cmd>CellularAutomaton game_of_life<CR>")
keymap.set("n", "<leader>ms", "<Cmd>CellularAutomaton slide<CR>")
