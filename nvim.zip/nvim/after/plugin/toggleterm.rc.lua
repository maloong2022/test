local status, toggleterm = pcall(require, 'toggleterm')
if (not status) then return end

toggleterm.setup({
  hide_numbers = true,
  shade_filetypes = {},
  shade_terminals = true,
  shading_factor = 2,
  start_in_insert = true,
  insert_mappings = true,
  persist_size = true,
  direction = "float",
  close_on_exit = true,
  shell = vim.o.shell,
  float_opts = {
    border = "curved", -- 'single' | 'double' | 'shadow' | 'curved' | ... other options supported by win open
    winblend = 0,
    highlights = {
      border = "Normal",
      background = "Normal",
    },
  },
})


local Terminal = require("toggleterm.terminal").Terminal

-- local lazygit = Terminal:new({ cmd = "lazygit", hidden = true })
local lazygit = Terminal:new({
  cmd = "lazygit",
  dir = "git_dir",
  direction = "float",
  float_opts = {
    border = "curved", -- 'single' | 'double' | 'shadow' | 'curved' | ... other options supported by win open
  },
  -- function to run on opening the terminal
  on_open = function(term)
    vim.cmd("startinsert!")
    vim.api.nvim_buf_set_keymap(term.bufnr, "n", "q", "<cmd>close<CR>", { noremap = true, silent = true })
  end,
  -- function to run on closing the terminal
  -- on_close = function(term)
  --   vim.cmd("Closing terminal")
  -- end,
})

function _LAZYGIT_TOGGLE()
  lazygit:toggle()
end

vim.api.nvim_set_keymap("n", "<leader>g", "<cmd>lua _LAZYGIT_TOGGLE()<CR>", { noremap = true, silent = true })

local ncdu = Terminal:new({ cmd = "ncdu --color off", hidden = true })

function _NCDU_TOGGLE()
  ncdu:toggle()
end

vim.api.nvim_set_keymap("n", "<leader>n", "<cmd>lua _NCDU_TOGGLE()<CR>", { noremap = true, silent = true })

local btop = Terminal:new({ cmd = "btop", hidden = true })

function _BTOP_TOGGLE()
  btop:toggle()
end

vim.api.nvim_set_keymap("n", "<leader>b", "<cmd>lua _BTOP_TOGGLE()<CR>", { noremap = true, silent = true })

local plan = Terminal:new({ cmd = "calcurse", hidden = true })

function _PLAN_TOGGLE()
  plan:toggle()
end

vim.api.nvim_set_keymap("n", "<leader>p", "<cmd>lua _PLAN_TOGGLE()<CR>", { noremap = true, silent = true })

local gitui = Terminal:new({
  cmd = "gitui", hidden = true
})

function _GITUI_TOGGLE()
  gitui:toggle()
end

vim.api.nvim_set_keymap("n", "<leader>v", "<cmd>lua _GITUI_TOGGLE()<CR>", { noremap = true, silent = true })
